﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShoppingSpree
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Get the input
            var people = Console.ReadLine().Split(new [] {';', '='}, StringSplitOptions.RemoveEmptyEntries);
            var products = Console.ReadLine().Split(new[] { ';', '='}, StringSplitOptions.RemoveEmptyEntries);

            Queue<string> peopleQueue = new Queue<string>(people);
            Queue<string> productsQueue = new Queue<string>(products);

            List<Person> peopleList = new List<Person>();
            List<Product> productsList = new List<Product>();

            bool exception = false;

            //Fill lists with people and products
            while(peopleQueue.Count > 0 && exception == false)
            { 
                try
                {   
                    var isDigit = 0.0;
                    var name = double.TryParse(peopleQueue.Peek(), out isDigit) ? null : peopleQueue.Dequeue();
                    var money = peopleQueue.Count > 0 ? double.Parse(peopleQueue.Dequeue()) : 0;

                    Person newPerson = new Person(name, money);
                    peopleList.Add(newPerson);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    exception = true;
                }
            }

            while(productsQueue.Count > 0 && exception == false)
            {
                try
                {
                    var isDigit = 0.0;
                    var product = double.TryParse(productsQueue.Peek(), out isDigit) ? null : productsQueue.Dequeue();
                    var cost = productsQueue.Count > 0 ? double.Parse(productsQueue.Dequeue()) : 0;

                    Product newProduct = new Product(product, cost);

                    productsList.Add(newProduct);
                }
                catch (Exception ex)
                { 
                    Console.WriteLine(ex.Message);
                    exception = true;
                }
            }

            //Buying products
            if (exception == false)
            {
                peopleList = BuyProducts(peopleList, productsList);
            }

            PrintList(peopleList);
            
        }


        private static List<Person> BuyProducts(List<Person> peopleList, List<Product> productsList)
        {
            while (true)
            {
                var buyingCommand = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (buyingCommand[0] == "END")
                {
                    break;
                }

                var person = buyingCommand[0];
                var productToPurchase = buyingCommand[1];

                var currentPerson = peopleList.FirstOrDefault(p => p.Name == person);
                var currentProduct = productsList.FirstOrDefault(p => p.Name == productToPurchase);

                if (currentPerson != null && currentProduct != null)
                {
                    try
                    {
                        currentPerson.AddProductToBag(currentProduct);
                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.Message);
                    }
                }
            }

            return peopleList;
        }

        private static void PrintList(List<Person> peopleList)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var person in peopleList)
            {
                sb.Append($"{person.Name.Trim()} - ");

                if (person.BagOfProducts.Count == 0)
                {
                    sb.Append("Nothing bought").AppendLine();
                }
                else
                {
                    var counter = 0;

                    foreach (var product in person.BagOfProducts)
                    {
                        counter++;
                        if (counter == person.BagOfProducts.Count)
                        {
                            sb.Append($"{product.Name}");
                        }
                        else
                        {
                            sb.Append($"{product.Name}, ");
                        }
                    }
                }
            }

            Console.WriteLine(sb.ToString().Trim());
        }
    }
}
