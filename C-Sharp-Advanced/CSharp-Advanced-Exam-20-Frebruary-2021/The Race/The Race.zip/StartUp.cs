﻿using System;

namespace TheRace
{
    public class StartUp
    {
        static void Main(string[] args)
        {
  
        }
    }
}
